# Export fixture

## Personal notes

English complete  
Dansk æøå ÆØÅ  
Español acción ¿Qué?  
Français été cœur  
Deutsch Grüße äöüß

## Transcript

\[01:01:01–01:01:05\] Camille  
Transcript preserved

![Drawing 1](assets/ink-1.png)

![Drawing 2](assets/ink-2.png)

